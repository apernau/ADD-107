import UIKit

// define Fibonacci Numbers function
func fibonacciNumbers () {
    // set variables for the first two numbers in the sequence: the starting number and the second number in the sequence
    var countStart = 0
    var countNext = 1
    // set the sequence limit to 1000
    var countLimit = 1000
    
    // use a control flow statement to effectively run the sequencing of numbers
    while countNext < countLimit { // loop runs as long as the next number in the sequence is less than the count limit - 1000
        print(countStart)
        var countingUp = countStart + countNext
        countStart = countNext
        countNext = countingUp
    }
}

// run the function
fibonacciNumbers()
