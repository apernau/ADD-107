import UIKit

// Creating a function to store the application
func myClock() {
    // creating a loop to keeo track of the current time
    while true {
        // Extracting the current time and date from the date formatter in swift
        let date = Date()
        let calendar = Calendar.current
        
        // defining the constants in the clock
        let hour = calendar.component(.hour, from: date)
        let minutes = calendar.component(.minute, from: date)
        let seconds = calendar.component(.second, from: date)
        
        // creating the clock string for print
        var time = String("\(hour): \(minutes): \(seconds)")
        
    }
}
// printing the current time
 print(time)

//starting the function to start the clock
myClock()
