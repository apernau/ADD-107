import UIKit

// set enum cases to patty choices for the burgers
enum MeatChoices: String {
    case beef, chicken, bison, veggie, cod
    // set meat variable and allow control flow to switch between choices
    var meatDescription: String {
        switch self {
        case .beef: return "Beef"
        case .chicken: return "Chicken"
        case .bison: return "Bison"
        case .veggie: return "Black Bean"
        case .cod: return "Cod"
        }
    }
}

// set enum cases to toppings choices for the burgers
enum Toppings: String {
    case lettuce, cheese, tomato, onion, pickle, mayo, ketchup, mustard
    // set toppings variable and allow control flow to switch between choices
    var toppingsDescription: String {
        switch self {
        case .lettuce: return "Lettuce"
        case .cheese: return "Cheese"
        case .tomato: return "Tomato"
        case .onion: return "Onion"
        case .pickle: return "Pickle"
        case .mayo: return "Mayo"
        case .ketchup: return "Ketchup"
        case .mustard: return "Mustard"
        }
    }
}

// set enum cases to bun choices for the burgers
enum BreadChoices: String {
    case brioche, pretzel, hawaiian, onion, glutenfree
    // set bun variable and allow control flow to switch between choices
    var bunDescription: String {
        switch self {
        case .brioche: return "Brioche"
        case .pretzel: return "Pretzel"
        case .hawaiian: return "Hawaiian"
        case .onion: return "Onion"
        case .glutenfree: return "Gluten-Free"
        }
    }
}

//define menu structure
struct Menu {
    // use optionals for the different choices on the burger
    var burgerItem: MeatChoices?
    var bunChoice: BreadChoices?
    var toppingChoice1: Toppings?
    var toppingChoice2: Toppings?
    var toppingChoice3: Toppings?
    // set burger variable
    var burgerDescription: String {
        var burger = "Your custom burger: "
        
        //choose meat
        if let burgerItem = burgerItem {
            burger += "\(burgerItem.meatDescription)"
        } else {
            burger += "No meat"
        }
        // add toppings
        var toppings: [String] = []
        if let topping1 = toppingChoice1 {
            toppings.append(topping1.toppingsDescription)
        }
        if let topping2 = toppingChoice2 {
            toppings.append(topping2.toppingsDescription)
        }
        if let topping3 = toppingChoice3 {
            toppings.append(topping3.toppingsDescription)
        }
        if !toppings.isEmpty {
            burger += " with " + toppings.joined(separator: ",")
        } else {
            burger += " with no toppings"
        }
        //choose bun
        if let bunChoice = bunChoice {
            burger += ", and a \(bunChoice.bunDescription) bun."
        } else {
            burger += ", and no bun."
        }
        // return the string with the custom built burger
        return burger
        }
    }


// run example
let customBurger = Menu (
    burgerItem: .cod,
    bunChoice: .brioche,
    toppingChoice1: .cheese,
    toppingChoice2: .lettuce,
    toppingChoice3: .tomato
)

//print the burger
print(customBurger.burgerDescription)

