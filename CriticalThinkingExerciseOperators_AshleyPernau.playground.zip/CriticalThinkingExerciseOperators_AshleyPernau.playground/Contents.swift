import UIKit

//Kilograms to Pounds Conversion Applicaton


// Defining Variables

var kg_value_1 = 15.00
var kg_value_2 = 20.00
var kg_value_3 = 25.00
var kg_value_4 = 30.00

// Defining Conversion Constant

let conversion_factor = 2.20462

// Calculate Pounds For Each Kilogram Value

var pounds_1 = kg_value_1 * conversion_factor
var pounds_2 = kg_value_2 * conversion_factor
var pounds_3 = kg_value_3 * conversion_factor
var pounds_4 = kg_value_4 * conversion_factor

// Output Results

print("\(kg_value_1) kilograms is equal to \(pounds_1) pounds.")
print("\(kg_value_2) kilograms is equal to \(pounds_2) pounds.")
print("\(kg_value_3) kilograms is equal to \(pounds_3) pounds.")
print("\(kg_value_4) kilograms is equal to \(pounds_4) pounds.")
