import UIKit

// Define constants for Book List
let HarryPotterOne = "Harry Potter and the Sorcerer's Stone"
let HarryPotterTwo = "Harry Potter and the Chamber of Secrets"
let HarryPotterThree = "Harry Potter and the Prisoner of Azkaban"
let HarryPotterFour = "Harry Potter and the Goblet of Fire"
let HarryPotterFive = "Harry Potter and the Order of the Phoenix"
let HarryPotterSix = "Harry Potter and the Half-Blood Prince"
let HarryPotterSeven = "Harry Potter and the Deathly Hallows"

let HungerGamesOne = "The Hunger Games"
let HungerGamesTwo = "Catching Fire"
let HungerGamesThree = "Mockingjay"
let HungerGamesPrequel = "The Ballad of Songbirds and Snakes"

// Define variables for Book List
var BookSeriesOneList = ""
var BookSeriesTwoList = ""

let newLine = "\n"

// Add Books To List and Update Series Titles

BookSeriesOneList += HarryPotterOne
BookSeriesOneList += newLine


BookSeriesOneList += HarryPotterTwo
BookSeriesOneList += newLine


BookSeriesOneList += HarryPotterThree
BookSeriesOneList += newLine


BookSeriesOneList += HarryPotterFour
BookSeriesOneList += newLine


BookSeriesTwoList += HungerGamesPrequel
BookSeriesTwoList += newLine


BookSeriesTwoList += HungerGamesOne
BookSeriesTwoList += newLine


BookSeriesOneList += HarryPotterFive
BookSeriesOneList += newLine


BookSeriesTwoList += HungerGamesTwo
BookSeriesTwoList += newLine


BookSeriesTwoList += HungerGamesThree


BookSeriesOneList += HarryPotterSix
BookSeriesOneList += newLine



BookSeriesOneList += HarryPotterSeven

print(BookSeriesOneList)
print(BookSeriesTwoList)

