import UIKit
// I thought about making a to do list for my daily life to help me keep better track of the things I have scheduled throughout the day and the things I add to the list as well. This helps me improve my daily errands and helps me to keep better track instead of relying on my memory (which I admittedly am very bad at remembering a lot of things lately.)

// set variables for the items in the to do list and its current status
    var List = [
        ("Pilates at 830", true),
        ("Take nephew to therapy at 10", true),
        ("Grocery shopping at Sams club", true),
        ("Pick up nephew after therapy at 1150", true),
        ("Grab lunch on the way home", false),
        ("Put kids down for a nap", false),
        ("Start laundry", true),
        ("Pick up kids from bus after school", false),
        ("Fold Laundry", true),
        ("Make dinner", false),
        ("Give kids a bath before bed", false),
        ("Put kids to bed", false),
        ("Work on schoolwork", false),
        ("Set alarms for the next day", false),
        ("Go to sleep", false)
    ]
    
// define the function to check for tasks based on a completed or incompleted closure
func tasksCheck(tasks: [(String, Bool)], using closure: ((String, Bool) -> Bool)) -> [(String, Bool)] {
    return tasks.filter(closure)
}
    
// use a closure to look for completed tasks
var tasksCompleted: (String, Bool) -> Bool = {_, isCompleted in
    return isCompleted
}
// use a closure to look for incompleted tasks
var tasksIncomplete: (String, Bool) -> Bool = {_, isCompleted in
    return !isCompleted
}

// get the current completed tasks in the list
var tasksDone = tasksCheck(tasks: List, using: tasksCompleted)

//get the current incomplete tasks in the list:
var tasksNotDone = tasksCheck(tasks: List, using: tasksIncomplete)

//print the list
print("Tasks Done:")
for task in tasksDone {
    print(task.0)
}

print("Tasks That Still To Be Done:")
for task in tasksNotDone {
    print(task.0)
}

