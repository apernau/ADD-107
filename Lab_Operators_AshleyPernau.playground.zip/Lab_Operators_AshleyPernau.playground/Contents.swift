import UIKit

// Input Variables

var a = 7
var b = 14
var c = 21

// Operations

var addition = a + b
var subtraction = c - a
var multiplication = b * c
var division = c / a
var percentage = b % a

// Results

print(addition)
print(subtraction)
print(multiplication)
print(division)
print(percentage)
